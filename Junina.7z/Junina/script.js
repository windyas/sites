function enviarMensagem(event) {
    event.preventDefault(); // Impede o envio padrão do formulário
    
    const form = event.target;
    const formData = new FormData(form);
    
    fetch('', {
        method: 'POST',
        body: formData
    }).then(response => response.text())
    .then(() => {
        form.reset();
        carregarMensagens();
    });
}

function carregarMensagens() {
    fetch('mensagens.php')
    .then(response => response.text())
    .then(data => {
        document.getElementById('mensagens').innerHTML = data;
    });
}

document.addEventListener('DOMContentLoaded', (event) => {
    carregarMensagens();
    setInterval(carregarMensagens, 1000); // Atualiza a cada 1 segundo
}); 