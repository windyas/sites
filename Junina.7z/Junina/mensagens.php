<?php
$dsn = "mysql:dbname=projeto_comentarios;host=localhost;port=3306;charset=utf8";
$user = "root";
$password = "";

$options = array(
    PDO::ATTR_CASE => PDO::CASE_LOWER,
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_PERSISTENT => true
);
$pdo = new PDO($dsn, $user, $password, $options);

$sql = "select * from mensagens order by data_msg desc";
$stmt = $pdo->query($sql);

if ($stmt->rowCount() > 0) {
    while ($row = $stmt->fetch()) {
        echo "<div class='mensagem'>";
        echo "<div class='nome'>";
        echo "<h1>" . $row['nome'] . "</h1>";
        echo "</div>";
        echo "<div class='msg'>";
        echo "<p>" . $row['msg'] . "</p>";
        echo "</div>";
        echo "</div>";
    }
} else {
    echo "Não existem mensagens!";
}
?>
