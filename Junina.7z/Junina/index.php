<?php

try {
    $dsn = "mysql:dbname=projeto_comentarios;host=localhost;port=3306;charset=utf8";
    $user = "root";
    $password = "";

    $options = array(
        PDO::ATTR_CASE => PDO::CASE_LOWER,
        PDO::ATTR_ERRMODE    => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_PERSISTENT => true
    );
    $pdo = new PDO($dsn, $user, $password, $options);
} catch (PDOException $e) {
    echo $e->getMessage();
}

if (isset($_POST['nome']) && !empty($_POST['nome'])) {
    $nome = $_POST['nome'];
    $mensagem = $_POST['mensagem'];

    $sql = "INSERT INTO mensagens (data_msg, nome, msg) VALUES (NOW(), :nome, :msg)";
    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(":nome", $nome);
    $stmt->bindValue(":msg", $mensagem);
    $stmt->execute();
    exit; // Termina a execução do script após inserção via AJAX
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="./styles/index.css">
    <title>Sistema de Mensagens</title>
</head>

<body>
    <header>
        <div class="icon">
            <img src="./img/love-letter.png" alt="">
        </div>
        <div class="title">
            <h1>Correio Elegante</h1>
        </div>
        <div class="icon"><img src="./img/love-letter.png" alt=""></div>
    </header>
    <div class="formulario">
        <div class="title">
            <h1>
                Envie sua mensagem de amor!
            </h1>
        </div>

        <div class="preencher">
            <form method="POST" onsubmit="enviarMensagem(event)">
                <h1>Nome e Destinatario</h1>
                <div class="input">
                    <input type="text" name="nome" required>
                </div>
                <h1>Mensagem</h1>
                <div class="input"><textarea name="mensagem" required></textarea></div>
                <div class="btn"><input type="submit" value="Enviar mensagem"></div>
        </div>
        </form>
    </div>
    <div class="sectionmensagens">
        <div class="title">
            <h1>Mensagens enviadas</h1>
        </div>
        <div class="mensagens">
        <div id="mensagens" class="mensagemhtml">
            </div>
        </div>
    </div>
    <script src="./script.js"></script>
    <br>
</body>

</html>