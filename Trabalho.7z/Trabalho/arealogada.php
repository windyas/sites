<?php 
session_start();
$loginvalue = $_SESSION['loginrequest'] ?? false;
if($loginvalue == false){
    $newURL = "./index";
    header('Location: '.$newURL.".php");
}
else{
    include_once './deletar.php';
}
?>