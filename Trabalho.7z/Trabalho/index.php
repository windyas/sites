<?php 
session_start();
require_once "./config.php"
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./assets/style.css">
    <link rel="shortcut icon" href="./assets/img/3686054.png" type="image/x-icon">
    <title>Login</title>
</head>

<body>
    <form action="<?= $_SERVER['PHP_SELF'] ?>" method="post">
        <div class="main">
            <div class="leftlogin">
                <h1>Faça Login<br>Para acessar nossa plataforma</h1>
                <img src="assets/img/Astronaut helmet-rafiki.png" alt="astronauta" class="image">
            </div>

            <div class="rightlogin">
                <div class="cardlogin">
                    <h1>Login</h1>
                    <div class="textfield">
                        <label for="user">Usuário</label>
                        <input type="text" name="user" id="user" placeholder="Insira seu usuário">
                    </div>
                    <div class="textfield">
                        <label for="password">Senha</label>
                        <input type="password" name="password" id="password" placeholder="Insira sua senha">
                        <div class="alinhar">
                            <a href="./criarconta.php" class="criar">Crie sua conta</a>
                        </div>
                    </div>
                    <button type="submit" class="btnlogin">Login</button>
                </div>
            </div>
        </div>
    </form>
</body>

</html>
<?php 
if(isset($_POST['user']) && isset($_POST['password'])){
    @$user = $_POST['user'];
@$password = $_POST['password'];
$sql = "SELECT * FROM `usarios` WHERE user = '$user';";
$sqlquery = $mysql -> query($sql) or DIE ('ERRO AO CONSULTAR' . $mysql -> error);
if($sqlquery->num_rows == 0){
    echo "<script>alert('O usuário e/ou senha não existem!');</script>";
}
else{
    $sqlnew = "SELECT * FROM `usarios` WHERE user = '$user' and senha = '$password';";
    $sqlnewquery = $mysql -> query($sqlnew);
    if($sqlnewquery -> num_rows == 0){
        echo "<script>alert('O usuário e/ou senha não existem!');</script>";
    }
    else{
        $newURL = "arealogada";
        $_SESSION['loginrequest'] = 1;
        header('Location: '.$newURL.".php");
    }
}
}
?>