<?php

    $hostname = "localhost";
    $username = "root";
    $password = "";
    $database = "users";

    $mysql = new mysqli($hostname, $username, $password, $database);
    