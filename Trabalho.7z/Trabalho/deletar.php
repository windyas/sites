<?php
require_once("config.php");
@$typeinput = $_GET['search'];
$sqlcode = "SELECT * FROM `usarios` WHERE id LIKE '%$typeinput%' or email LIKE '%$typeinput%' or user LIKE '%$typeinput%'";
$sqlquery = $mysql -> query($sqlcode) or DIE ("ERRO AO CONSULTAR!" . $mysql -> error);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./assets/mystyle.css">
    <link rel="shortcut icon" href="./assets/img/3686054.png" type="image/x-icon">
    <title>Document</title>
</head>

<body>
    <div class="main">
        <div class="title">
            <h1>Manipulação de usuário</h1>
        </div>
        <div class="tables">
            <div class="usertable">
                <form action="<?= $_SERVER['PHP_SELF'] ?>" method="get">
                    <div class="inputsusertable">
                        <input type="text" name="search" id="search">
                        <button type="submit">Pesquisar usuário</button>
                    </div>
                    <table width="600px">
                        <tr>
                            <th>Id</th>
                            <th>Email</th>
                            <th>Usuário</th>
                        </tr>
                        <?php 
            if(!isset($_GET['search'])){
                ?>
                        <!--<tr>
                            <td colspan="3">Pesquise por algo...</td>
                        </tr> -->
                        <?php }
           if($sqlquery -> num_rows == 0){
            ?>
                        <tr>
                            <td colspan="3">Nenhum resultado encontrado...</td>
                        </tr>
                        <?php
           }
           else{
            while($dados = $sqlquery->fetch_assoc()){ ?>
                        <div class="tabledate">
                            <tr>
                                <td><?php echo $dados['id']?></td>
                                <td><?php echo $dados['email']?></td>
                                <td><?php echo $dados['user']?></td>
                            </tr>
                        </div>
                        <?php 
            }
           }
            ?>
                    </table>
                </form>
            </div>
            <div class="deletetable">
                <form action="" method="get">
                    <div class="inputdeletable">
                        <input type="text" name="delete" id="delete">
                        <button type="submit2">Delete um usuário</button>
                    </div>
                    <?php 
    if(isset($_GET['delete'])){
        @$deleteinp = $_GET['delete'];
        $sqlcode2 = "SELECT * FROM `usarios` WHERE id LIKE '$deleteinp' or email LIKE '$deleteinp' or user LIKE '$deleteinp'";
        $sqlquery3 = $mysql -> query($sqlcode2) or DIE ("ERRO AO CONSULTAR!" . $mysql -> error);
        if($sqlquery3 -> num_rows == 0){
            echo '<div class="deleteditemsucess"><p>Nenhum usuário correspondente</p></div>';
        }
        else{
        @$deleteinput = $_GET['delete'];
        $sqldelete = "DELETE FROM `usarios` WHERE id LIKE '$deleteinput' or email LIKE '$deleteinput' or user LIKE '$deleteinput'";
        $sqlquery2 = $mysql->query($sqldelete) or DIE ('ERRO AO DELETAR' . $mysql->error);
            echo '<div class="deleteditemsucess"><p>Item deletado com sucesso</p></div>';
        }
    }
    ?>
                </form>
            </div>
            <div class="updateform">
                <form action="" method="get">
                    <div class="formupdate">
                        <div class="inputsupdate">
                            <br>
                            <div class="inpp">
                                <label for="update">Qual usuário alterar</label>
                                <input type="number" name="update" id="update">
                                <br>
                                <br>
                                <label for="whatupdate">Alterar usuário para</label>
                                <input type="text" name="whatupdate" id="whatupdate">
                            </div>
                            <div class="inp">
                                <p>Qual campo alterar</p>
                                <div class="inputtt">
                                    <input type="radio" name="inputtype" id="inputuser" value="user">
                                    <label for="inputuser">Usuário</label>
                                    <input type="radio" name="inputtype" id="inputemail" value="email">
                                    <label for="inputemail">Email</label>
                                    <input type="radio" name="inputtype" id="inputsenha" value="password">
                                    <label for="inputsenha">Senha</label>
                                </div>
                            </div>
                            <br>
                        </div>
                    </div>
            </div>
            <div class="buttonupdate">
                <button type="submit33">Alterar</button>
            </div>
        </div>
        <?php 
        if(isset($_GET['update']) && isset($_GET['whatupdate']) && isset($_GET['inputtype'])){
            @$mudar = $_GET['whatupdate'];
            @$qual = $_GET['inputtype'];
            @$user = $_GET['update'];
            $mycodesql = "UPDATE `usarios` SET `$qual`='$mudar' WHERE id LIKE '$user'";
            $query = $mysql -> query($mycodesql) or DIE ('ERRO AO ALTERAR' . $mysql -> error);
        }
        ?>
        </form>
        <button onclick="location.href='finalizarsessao.php'">Finalizar sessão</button>
    </div>
</body>

</html>