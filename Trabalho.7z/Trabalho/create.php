<?php
session_start();
$allow = 0;
$newURL = "./index";
include "config.php";
if(isset($_POST['submit']) && $_POST['password'] != "" && $_POST['user'] != "" && $_POST['email'] != ""){
    $user = $_POST['user'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $sqlmycode = "SELECT * FROM `usarios` WHERE (`user`) = '$user'";
    $query = $mysql->query($sqlmycode) or die ('ERRO AO CONSULTAR' . $mysql->error);
    if($query->num_rows == 0){
        $sqlcode = "INSERT INTO `usarios`(`email`, `user`, `senha`) VALUES ('$email','$user','$password')";
        $sql_query = $mysql->query($sqlcode) or die("ERRO AO CONSULTAR" . $mysql->error);
        header('Location: '.$newURL.".php");
        $allow = 1;
        if($allow = 1){
            header('Location: '.$newURL.".php");
        }
        else{
            return false;
        }
    }
    else{
        $_SESSION['loginerror'] = 1;
        $URL = 'loginerror';
        header('Location: '.$URL.".php");
    }
}
?>

