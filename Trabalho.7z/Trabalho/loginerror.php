<?php 
session_start();
if($_SESSION['loginerror'] == 1){
    include_once 'criarconta.php';
    echo "<script>alert('O usuário já existe!');</script>";
    $_SESSION['loginerror'] == 0;
}
else{
    include_once 'criarconta.php';
}
?>