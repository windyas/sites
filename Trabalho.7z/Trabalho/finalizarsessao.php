<?php 
session_start();
$_SESSION['loginrequest'] = 0;
$newURL = "./index";
header('Location:' . $newURL . ".php");
?>