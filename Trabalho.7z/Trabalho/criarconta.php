<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./assets/style.css">
    <link rel="shortcut icon" href="./assets/img/3686054.png" type="image/x-icon">
    <title>Criar conta</title>
</head>

<body>
    <form action="create.php" method="post">
        <div class="main">
            <div class="leftlogin">
                <h1>Crie sua conta<br>De maneira gratuita!</h1>
                <img src="assets/img/World radio day-amico.png" alt="astronauta" class="image">
            </div>

            <div class="rightlogin">
                <div class="cardlogin">
                    <h1>Cadastro</h1>
                    <div class="textfield">
                        <label for="email">Email</label>
                        <input type="email" name="email" id="email" placeholder="Insira seu email" required>
                    </div>
                    <div class="textfield">
                        <label for="user">Usuário</label>
                        <input type="text" name="user" id="user" placeholder="Insira seu usuário" required>
                    </div>
                    <div class="textfield">
                        <label for="password">Senha</label>
                        <input type="password" name="password" id="password" placeholder="Insira sua senha" required>
                        <div class="alinhar">
                            <a href="./index.php" class="criar">Ja tem uma conta?</a>
                        </div>
                    </div>
                    <button type="submit" class="btnlogin" name="submit" id="submit">Criar conta</button>
                </div>
            </div>
        </div>
    </form>
</body>

</html>