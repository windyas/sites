<?php
require_once 'config.php';
date_default_timezone_set('America/Sao_Paulo');
if($_POST['nome'] && $_POST['mensagem']){
    $nome = $_POST['nome'];
    $mensagem = $_POST['mensagem'];
    $date = date('Y-m-d H:i:s');
    $sqlrequest = "INSERT INTO `mensagens`(`nome`, `data_msg`, `msg`) VALUES ('$nome','$date','$mensagem')";
    $sqlquery = $mysql->query($sqlrequest);
    $request = 1;
    if($request){
        $newURL = 'juarezgram';
        header('location: ' . $newURL . '.php'); 
    }
}
else{
    $newURL = 'juarezgram';
    header('location: ' . $newURL . '.php'); 
}