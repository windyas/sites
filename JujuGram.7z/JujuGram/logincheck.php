<?php 
require_once 'config.php';
if($_POST['login'] && $_POST['senha']){
    $login = $_POST['login'];
    $senha = $_POST['senha'];
    $sqlrequest = "SELECT * FROM `usuarios` WHERE `user` = '$login' and `senha` = '$senha'";
    $sqlquery = $mysql->query($sqlrequest);
    if($sqlquery->num_rows > 0){
        $newURL = 'juarezgram';
        header('location: ' . $newURL . '.php');
    }
    else{
        $newURL = 'index';
        header('location: ' . $newURL . '.php'); 
    }
}
else{
    $newURL = 'index';
    header('location: ' . $newURL . '.php'); 
}
?>