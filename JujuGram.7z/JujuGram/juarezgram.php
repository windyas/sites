<?php 
include_once 'config.php';
$sqlrequest = "SELECT * FROM `mensagens`";
$sqlquery = $mysql->query($sqlrequest);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/style.css">
    <link rel="shortcut icon" href="assets/img/instagram.png" type="image/x-icon">
    <title>Jujugram</title>
</head>

<body>
    <div class="main">
        <img src="assets/img/juarez.jpeg" alt="">
        <form method="POST" action="sendcoment.php">
            Nome: <br />
            <input type="text" name="nome">
            <br /><br />
            Mensagem<br />
            <textarea name="mensagem"></textarea>
            <br />
            <br />
            <input type="submit" value="Enviar mensagem">
        </form>
    <div class="comentarios">
    <?php 
    if($sqlquery->num_rows > 0){
        while($row = $sqlquery->fetch_assoc() ){
           echo "<strong>" . $row['nome'] . "</strong><br/>";
           echo $row['data_msg'] . "<br/>";
           echo $row['msg'] . "<br/>";
           echo "<hr>";
        }
     } else {
         echo "Não existem mensagens!";
     }
    ?>
    
    </div>
</body>
</html>