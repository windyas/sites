<?php
$dbuser = "root";
$db = "login";
$dbhost = "localhost";
$dbpassword = "";

$mysql = new mysqli($dbhost,$dbuser,$dbpassword,$db);