<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/style.css">
    <link rel="shortcut icon" href="assets/img/instagram.png" type="image/x-icon">
    <title>Jujugram</title>
</head>
<body>
    <div class="main">
        <div class="section">
        <div class="login">
            <div class="title">
                <h1>Juarezgram</h1>
            </div>
            <form action="logincheck.php" method="post">
            <div class="input">
                <input type="text" placeholder="Telefone, nome de usuário ou email" name="login" id="login">
                <input type="password" name="senha" id="senha" placeholder="Senha">
            </div>
            <div class="button">
                <button type="submit" value="submit" id="submit">Entrar</button>
            </div>
            </form>
            <div class="forget">
                <a href="#">Esqueceu a senha?</a>
            </div>
        </div>
        <div class="create">
            <div class="p"><p>Não tem uma conta?</p></div>
            <div class="a"><a href="#">Cadastre-se</a></div>
        </div>
        <div class="getapp">
            <div class="p"><h1>Obtenha o aplicativo</h1></div>
            <div class="downloadbutton">
                <img src="assets/img/appstore.png" alt="">
                <img src="assets/img/playstore (1).png" alt="">
            </div>
        </div>
        </div>
    </div>
</body>
</html>