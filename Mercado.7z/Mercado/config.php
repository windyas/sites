<?php

$hostname = "localhost";
$username = "root";
$password = "";
$database = "mercado";

$mysql = new mysqli($hostname, $username, $password, $database);

/*
O codigo acima faz uma
conexão com banco de dados.
*/
?>