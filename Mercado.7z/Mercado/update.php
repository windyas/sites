<?php 
require_once 'config.php';
$request = 1;
$newURL = 'login';
$id = $_POST['id'];
$item = $_POST['itemvalue'];
$update = $_POST['update'];
$sqlrequest = "UPDATE `produtos` SET `$item`='$update' WHERE `id` = '$id'";
$sqlquery = $mysql->query($sqlrequest) or DIE ('ERRO AO ALTERAR');
if($request == 1 && $request != NULL){
    header('location:' . $newURL . '.php');
}
?>