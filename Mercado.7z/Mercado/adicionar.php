<?php 
require_once 'config.php';
$produto = $_POST['produto'];
$fabricante = $_POST['fabricante'];
$descricao = $_POST['descricao'];

$sqlrequest = "INSERT INTO `produtos`(`nome_produto`, `fabricante`, `desc_produto`) VALUES ('$produto','$fabricante','$descricao')";
$mysqlquery = $mysql->query($sqlrequest) or DIE ('ERRO AO CONSULTAR' . $mysql->error);
$request = 1;
$newURL = "login";
if($request == 1 && $request != NULL){
    header('Location:' . $newURL . ".php");
}
/*
O codigo acima faz uma
solicitação para o banco de
dados atraves de dados enviados
via POST e com isso cria um novo
usuário no banco de dados.
*/
?>