<?php 
require_once 'config.php';
$request = 1;
$newURL = 'login';
$id = $_GET['id'];
$sqlrequest = "DELETE FROM `produtos` WHERE `id` = $id";
$sqlquery = $mysql->query($sqlrequest) or DIE('ERRO AO DELETAR' . $mysql->error);
if($request == 1 && $request != NULL){
    header('location:' . $newURL . '.php');
}
/*
O codigo acima envia uma
query para o banco de dados
a partir de um id compartilhado
via metodo GET, e com isso exclui
o usuário referente ao ID.
*/
?>
