<?php 
require_once 'config.php';
$search = $_GET['pesquisa'] ?? NULL;
$sqlquery1 = "SELECT * FROM `produtos` WHERE `id` LIKE '%$search%' or `nome_produto` LIKE '%$search%'";
$sqlquery2 = "SELECT * FROM `produtos`";
$pesquisaquery2 = $mysql -> query($sqlquery2); 
$pesquisaquery = $mysql -> query($sqlquery1);
$numrows = $pesquisaquery -> num_rows;
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./assets/style.css">
    <title>Lista do mercado</title>
</head>

<body>
    <div class="main">
        <!-- Main contendo todo conteudo do site -->
        <div class="navbar">
            <!-- Navbar contendo a barra de navegação -->
            <nav>
                <div class="logo">
                    <!-- Logo dentro da Navbar -->
                    <h1>Juarez mercados</h1>
                    <img src="./assets/img/carrinho-de-compras.png" alt="Carrinho de compras">
                </div>
                <div class="nav">
                    <!-- Opções de navegação dentro da Navbar -->
                    <ul>
                        <li><a href="#home">Home</a></li>
                        <li><a href="#estoque">Estoque</a></li>
                        <li><a href="#contato">Contato</a></li>
                        <li><a href="index.php">Sair</a></li>
                    </ul>
                </div>
            </nav>
        </div>
        <div class="home" id="home">
            <!-- Informações básicas do mercado -->
            <section>
                <div class="title">
                    <!-- Titulo & imagem da aba Home -->
                    <h1>O melhor mercado da sua região</h1>
                    <img src="./assets/img/mercado_image.jpg" alt="Mercado visto de fora">
                </div>
                <div class="content">
                    <!-- Texto da aba Home -->
                    <p>Bem vindo ao sistema integrado de gerenciamento ao estoque da rede de supermercados mais famosa
                        do Brasil!</p>
                </div>
            </section>
        </div>
        <main>
            <div class="estoque">
                <!-- Aba estoque -->

                <section id="estoque">
                    <div class="title">Acesso ao estoque</div> <!-- Titulo da aba -->
                    <div class="tabela">

                        <table>
                            <!-- Tabela da aba -->
                            <tr>
                                <td>Id</td>
                                <td>Produto</td>
                                <td>Fabricante</td>
                                <td>Descrição</td>
                                <td>Deletar produto</td>
                            </tr>
                            <!-- Inicio do código PHP-->
                            <?php
                                if(!isset($_GET['pesquisa'])){ /* Enquanto existirem itens, exibira eles */
                                    while($dados2 = $pesquisaquery2->fetch_assoc()){
                                    ?>
                            <tr>
                                <td><?php echo $dados2['id']?></td>
                                <td><?php echo $dados2['nome_produto']?></td>
                                <td><?php echo $dados2['fabricante']?></td>
                                <td><?php echo $dados2['desc_produto']?></td>
                                <td><a href="deletar.php?id=<?php echo $dados2['id']?>">Deletar</a></td>
                            </tr>
                            <?php    
                                    }
                                }
                                if(isset($_GET['pesquisa']) && empty($_GET['pesquisa']) == true){
                            ?>
                            <tr>
                                <td colspan="5">Pesquise por algo...</td>
                                <!-- Se nada for pesquisado
                                                                                Imprime uma requisição -->
                            </tr>
                            <?php 
                                } 
                                if(@$numrows == 0 && isset($_GET['pesquisa']) && empty($_GET['pesquisa']) == false){ 
                            ?>
                            <tr>
                                <td colspan="5">Nenhum resultado encontrado!</td>
                                <!-- Se não existirem resultados
                                                                                            Imprime uma mensagem  -->
                            </tr>

                            <?php    
                                }
                                if(@$numrows != 0 && isset($_GET['pesquisa']) && empty($_GET['pesquisa']) == false){
                                    while($dados = $pesquisaquery->fetch_assoc()){ ?>
                            <!-- Enquanto existirem resutados
                                                                                            Imprime uma tabela com eles -->
                            <tr>
                                <td><?php echo $dados['id']?></td>
                                <td><?php echo $dados['nome_produto']?></td>
                                <td><?php echo $dados['fabricante']?></td>
                                <td><?php echo $dados['desc_produto']?></td>
                                <td><a href="deletar.php?id=<?php echo $dados2['id']?>">Deletar</a></td>
                            </tr>
                            <?php            
                                    }
                                }
                            ?>
                            <!-- Final do código PHP -->
                        </table>
                    </div>
                    <div class="pesquisa">
                        <!-- Pesquisar um item -->
                        <form action="<?= $_SERVER['PHP_SELF']?>" method="get">
                            <!-- Formulário de pesquisa -->
                            <label for="pesquisa">Pesquise por um item</label>
                            <input type="text" name="pesquisa" id="pesquisa">
                            <button type="submit">Pesquisar</button>
                        </form>
                    </div>
                    <div class="update">
                        <div class="title">
                            <h1>Adicionar produto</h1> <!-- Exibira um formulario para adicionar produtos via POST -->
                        </div>
                        <div class="contentadd">
                            <form action="adicionar.php" method="post">
                                <div class="contentaddinputs">
                                    <label for="produto">Produto</label>
                                    <input type="text" name="produto" id="produto" required>
                                </div>
                                <div class="contentaddinputs">
                                    <label for="fabricante">Fabricante</label>
                                    <input type="text" name="fabricante" id="fabricante" required>
                                </div>
                                <div class="contentaddinputs">
                                    <label for="descricao">Descrição</label>
                                    <input type="text" name="descricao" id="descricao" required>
                                </div>
                                <div class="contentaddbutton">
                                    <button type="submit">Adicionar</button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="update">
                        <div class="title">
                            <h1>Alterar produto</h1> 
                        </div>
                        <div class="contentupdate"> <!-- Exibira um formulario para alterar produtos via POST -->
                            <form action="update.php" method="post">
                                <div class="itemupdate">
                                    <div class="contentaddinputs">
                                        <label for="id">Id do Produto</label>
                                        <input type="number" name="id" id="id">
                                    </div>
                                </div>
                                <div class="marcar">
                                    <div class="updatelabel">
                                        <label for="item">O que mudar</label>
                                    </div>
                                    <div class="updateinput">
                                        <input type="radio" name="itemvalue" value="nome_produto"
                                            id="nome_produto"><label for="nome_produto">Produto</label>
                                        <input type="radio" name="itemvalue" value="fabricante" id="fabric"><label
                                            for="fabric">Fabricante</label>
                                        <input type="radio" name="itemvalue" value="desc_produto"
                                            id="desc_produto"><label for="desc_produto">Descrição</label>
                                    </div>
                                </div>
                                <div class="itemupdate">
                                    <div class="contentaddinputs">
                                        <label for="update">Mudar para</label>
                                        <input type="text" name="update" id="update" required>
                                    </div>
                                    <div class="updatesubmit">
                                        <button type="submit">Alterar</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </section>
            </div>
        </main>
        <footer>
            <div class="contato">
                <!-- Aba do contato -->
                <section id="contato">
                    <div class="first">
                        <!-- Sobre nós -->
                        <h1>Quem somos nós?</h1>
                        <p>Juarez mercados é uma empresa focada em trazer o melhor custo beneficio para seus clientes,
                            desde 1990 credenciada pelo JuarezCredenciais.</p>
                    </div>
                    <hr>
                    <div class="second">
                        <!-- Contato -->
                        <h1>Onde nos encontrar?</h1>
                        <div class="icons">
                            <!-- Icones -->
                            <div class="icone"><img src="./assets/img/e-mail.png" alt=""><label for=""><a
                                        href="">contato@juarezmercados.com</a></label></div>
                            <div class="icone"><img src="./assets/img/instagram.png" alt=""><label for=""><a
                                        href="">@juarezmercados</a></label></div>
                            <div class="icone"><img src="./assets/img/whatsapp.png" alt=""><label for=""><a
                                        href="#">(37) 99999-9999</a></label>
                            </div>
                        </div>
                </section>
            </div>
        </footer>
    </div>
</body>

</html>